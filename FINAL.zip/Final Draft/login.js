const express = require('express');
const bodyParser = require('body-parser');
const path = require('path');
const mysql = require('mysql');

const app = express();
const port = 3000;

// Create a connection pool to the database
const pool = mysql.createPool({
  connectionLimit: 10,
  host: 'localhost',
  user: 'root',
  password: 'password',
  database: 'cornermarketdb'
});

app.use(bodyParser.urlencoded({ extended: true }));
app.use(express.static(path.join(__dirname, 'public')));

app.get('/', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'login.html'));
});

// Define a route to handle the form submission
app.post('/submit', (req, res) => {
  const name = req.body.name;
  const email = req.body.email;
  const password = req.body.password;

  // Get a connection from the pool
  pool.getConnection((err, connection) => {
    if (err) {
      console.error('Error getting database connection: ' + err.stack);
      res.status(500).send('Internal Server Error');
      return;
    }

    // Insert the user input into the database
    const sql = "INSERT INTO user_table (name, email, password) VALUES (?, ?, ?)";
    connection.query(sql, [name, email, password], (err, result) => {
      connection.release(); // Release the connection back to the pool

      if (err) {
        console.error('Error inserting data: ' + err.stack);
        res.status(500).send('Internal Server Error');
        return;
      }

      console.log('User created successfully');
      res.status(200).send('User created successfully');
    });
  });
});

// Define a route to handle the login request
app.post('/login', (req, res) => {
  const email = req.body.email;
  const password = req.body.password;

  // Get a connection from the pool
  pool.getConnection((err, connection) => {
    if (err) {
      console.error('Error getting database connection: ' + err.stack);
      res.status(500).send('Internal Server Error');
      return;
    }

    // Query the database for login verification
    const sql = "SELECT * FROM user_table WHERE email = ? AND password = ?";
    connection.query(sql, [email, password], (err, result) => {
      connection.release(); // Release the connection back to the pool

      if (err) {
        console.error('Error executing database query: ' + err.stack);
        res.status(500).send('Internal Server Error');
        return;
      }

      if (result.length === 1) {
        // If login is successful, send success response
        res.status(200).send('Login successful');
      } else {
        // If login fails, send failure response
        res.status(401).send('Login failed');
      }
    });
  });
});

// Start the server
app.listen(port, () => {
  console.log(`Server listening on port ${port}`);
});
