const express = require('express');
const mysql = require('mysql');
const path = require('path');

const app = express();
const port = 3000;

const connection = mysql.createConnection({
  host: 'localhost',
  user: 'root',
  password: 'password',
  database: 'cornermarketdb'
});

connection.connect((err) => {
  if (err) throw err;
  console.log('Connected to the MySQL server!');
});

app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(express.static('public'));

// Define the pool for handling database connections
const pool = mysql.createPool({
  connectionLimit: 10,
  host: 'localhost',
  user: 'root',
  password: 'password',
  database: 'cornermarketdb'
});

app.get('/', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'login.html'));
});

// Define a route to handle the form submission
app.post('/submit', (req, res) => {
  const name = req.body.name;
  const email = req.body.email;
  const password = req.body.password;

  // Get a connection from the pool
  pool.getConnection((err, connection) => {
    if (err) {
      console.error('Error getting database connection: ' + err.stack);
      res.status(500).send('Internal Server Error');
      return;
    }

    // Insert the user input into the database
    const sql = "INSERT INTO user_table (name, email, password) VALUES (?, ?, ?)";
    connection.query(sql, [name, email, password], (err, result) => {
      connection.release(); // Release the connection back to the pool

      if (err) {
        console.error('Error inserting data: ' + err.stack);
        res.status(500).send('Internal Server Error');
        return;
      }

      console.log('User created successfully');
      res.status(200).send('User created successfully');
    });
  });
});

// Define a route to handle the login request
app.post('/login', (req, res) => {
  const email = req.body.email;
  const password = req.body.password;

  // Get a connection from the pool
  pool.getConnection((err, connection) => {
    if (err) {
      console.error('Error getting database connection: ' + err.stack);
      res.status(500).send('Internal Server Error');
      return;
    }

    // Query the database for login verification
    const sql = "SELECT * FROM user_table WHERE email = ? AND password = ?";
    connection.query(sql, [email, password], (err, result) => {
      connection.release(); // Release the connection back to the pool

      if (err) {
        console.error('Error executing database query: ' + err.stack);
        res.status(500).send('Internal Server Error');
        return;
      }

      if (result.length === 1) {
        // If login is successful, send success response
        res.status(200).send('Login successful');
      } else {
        // If login fails, send failure response
        res.status(401).send('Login failed');
      }
    });
  });
});
//ADDED HERE
app.post('/submit-form', (req, res) => {
  const name = req.body.name;
  const email = req.body.email;
  const subject = req.body.subject;
  const message = req.body.message;

  // Get a connection from the pool
  pool.getConnection((err, connection) => {
    if (err) {
      console.error('Error getting database connection: ' + err.stack);
      res.status(500).send('Internal Server Error');
      return;
    }

    // Insert the user input into the contact_table
    const sql = "INSERT INTO contact_table (name, email, subject, message) VALUES (?, ?, ?, ?)";
    connection.query(sql, [name, email, subject, message], (err, result) => {
      connection.release(); // Release the connection back to the pool

      if (err) {
        console.error('Error executing database query: ' + err.stack);
        res.status(500).send('Internal Server Error');
        return;
      }

      console.log('Form submitted successfully');
      res.status(200).send('Form submitted successfully');
    });
  });
});

//ENDS HERE
      app.get('/products', (req, res) => {
        const productType = req.query.type;
      
        if (productType=='Drink') {
          const query = `
            SELECT Inventory_table.product_ID, Inventory_table.product_name, Inventory_table.Product_type, Inventory_table.Aislenumber, Inventory_table.Stock_level, Inventory_table.price, Image_table.Image_path
            FROM Inventory_table
            JOIN Image_table ON Inventory_table.image_ID = Image_table.image_ID
            WHERE LOWER(Inventory_table.Product_type) = ?
          `;
      
          connection.query(query, [productType.toLowerCase()], (err, result) => {
            if (err) {
              console.error('Error executing database query: ' + err.stack);
              res.status(500).send('Internal Server Error');
              return;
            }
      
            res.json(result);
          });
        } 
        else if(productType=='Food'){
          const query = `
            SELECT Inventory_table.product_ID, Inventory_table.product_name, Inventory_table.Product_type, Inventory_table.Aislenumber, Inventory_table.Stock_level, Inventory_table.price, Image_table.Image_path
            FROM Inventory_table
            JOIN Image_table ON Inventory_table.image_ID = Image_table.image_ID
            WHERE LOWER(Inventory_table.Product_type) = ?
          `;
      
          connection.query(query, [productType.toLowerCase()], (err, result) => {
            if (err) {
              console.error('Error executing database query: ' + err.stack);
              res.status(500).send('Internal Server Error');
              return;
            }
      
            res.json(result);
          });
        }
        else if(productType=='Medicine'){
          const query = `
            SELECT Inventory_table.product_ID, Inventory_table.product_name, Inventory_table.Product_type, Inventory_table.Aislenumber, Inventory_table.Stock_level, Inventory_table.price, Image_table.Image_path
            FROM Inventory_table
            JOIN Image_table ON Inventory_table.image_ID = Image_table.image_ID
            WHERE LOWER(Inventory_table.Product_type) = ?
          `;
      
          connection.query(query, [productType.toLowerCase()], (err, result) => {
            if (err) {
              console.error('Error executing database query: ' + err.stack);
              res.status(500).send('Internal Server Error');
              return;
            }
      
            res.json(result);
          });
        }
        else if(productType=='Hygiene'){
          const query = `
            SELECT Inventory_table.product_ID, Inventory_table.product_name, Inventory_table.Product_type, Inventory_table.Aislenumber, Inventory_table.Stock_level, Inventory_table.price, Image_table.Image_path
            FROM Inventory_table
            JOIN Image_table ON Inventory_table.image_ID = Image_table.image_ID
            WHERE LOWER(Inventory_table.Product_type) = ?
          `;
      
          connection.query(query, [productType.toLowerCase()], (err, result) => {
            if (err) {
              console.error('Error executing database query: ' + err.stack);
              res.status(500).send('Internal Server Error');
              return;
            }
      
            res.json(result);
          });
        }
        else if(productType=='Stationery'){
          const query = `
            SELECT Inventory_table.product_ID, Inventory_table.product_name, Inventory_table.Product_type, Inventory_table.Aislenumber, Inventory_table.Stock_level, Inventory_table.price, Image_table.Image_path
            FROM Inventory_table
            JOIN Image_table ON Inventory_table.image_ID = Image_table.image_ID
            WHERE LOWER(Inventory_table.Product_type) = ?
          `;
      
          connection.query(query, [productType.toLowerCase()], (err, result) => {
            if (err) {
              console.error('Error executing database query: ' + err.stack);
              res.status(500).send('Internal Server Error');
              return;
            }
      
            res.json(result);
          });
        }

        else {
          res.json([]);
        }
      });
      
      
      
      
      app.listen(port, () => {
      console.log('Server is listening at http://localhost:${port}');
      });