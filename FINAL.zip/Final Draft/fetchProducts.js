async function fetchProducts() {
  try {
    const response = await fetch('http://localhost:8000/fetch_products');
    const products = await response.json();
    const productsContainer = document.getElementById('productsContainer');

    for (const product of products) {
      productsContainer.innerHTML += `
        <div style="width: 200px; margin: 10px;">
          <img src="${product.image_path}" style="width: 100%;">
          <hr>
          Price: ${product.price}
          <hr>
          Stock Level: ${product.stock_level}
          <hr>
          Aisle: ${product.aislenumber}
          <hr style="border-color: blue;">
        </div>
      `;
    }
  } catch (error) {
    console.error('Error fetching products:', error);
  }
}

fetchProducts();
